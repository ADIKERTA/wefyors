/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        blue: {
          50: '#f0f7ff',
          100: '#e0eefe',
          200: '#bcdafc',
          300: '#90bef9',
          400: '#5a9cf5',
          500: '#3182f6',
          600: '#1a6de5',
          700: '#1558c2',
          800: '#154a9e',
          900: '#173d79',
        },
        gold: {
          50: '#fdf9e9',
          100: '#fbf0c7',
          200: '#f6e092',
          300: '#f1cb52',
          400: '#ecb322',
          500: '#dfa00e',
          600: '#c27c0a',
          700: '#9b5a0d',
          800: '#7f4712',
          900: '#6a3a14',
        },
      },
      fontFamily: {
        sans: ['Poppins', 'Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
};