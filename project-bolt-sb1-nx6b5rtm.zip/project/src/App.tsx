import React from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import AcademicsSection from './components/AcademicsSection';
import FacilitiesSection from './components/FacilitiesSection';
import TestimonialsSection from './components/TestimonialsSection';
import NewsSection from './components/NewsSection';
import CallToActionSection from './components/CallToActionSection';
import Footer from './components/Footer';

function App() {
  return (
    <div className="font-['Poppins',_sans-serif]">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <AcademicsSection />
      <FacilitiesSection />
      <TestimonialsSection />
      <NewsSection />
      <CallToActionSection />
      <Footer />
    </div>
  );
}

export default App;