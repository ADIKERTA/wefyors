import React from 'react';
import { BookOpen, Target, Users } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Welcome to Elite Academy</h2>
          <div className="w-20 h-1 bg-gold-500 mx-auto"></div>
          <p className="text-gray-600 max-w-3xl mx-auto mt-6 text-lg">
            For over 25 years, we've been committed to providing exceptional education
            that fosters academic excellence, personal growth, and ethical leadership.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-blue-50 p-8 rounded-lg transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <BookOpen className="text-blue-900" size={28} />
            </div>
            <h3 className="text-xl font-bold text-blue-900 mb-4">Our Story</h3>
            <p className="text-gray-600">
              Founded in 1998, Elite Academy began with a vision to create a learning environment
              where students could thrive academically while developing character and leadership skills.
              Today, we've grown into one of the region's most respected educational institutions.
            </p>
          </div>

          <div className="bg-blue-50 p-8 rounded-lg transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <Target className="text-blue-900" size={28} />
            </div>
            <h3 className="text-xl font-bold text-blue-900 mb-4">Our Mission</h3>
            <p className="text-gray-600">
              We aim to provide a transformative educational experience that inspires academic excellence,
              fosters personal growth, and cultivates ethical leadership, preparing students to
              contribute meaningfully to a global society.
            </p>
          </div>

          <div className="bg-blue-50 p-8 rounded-lg transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <Users className="text-blue-900" size={28} />
            </div>
            <h3 className="text-xl font-bold text-blue-900 mb-4">Our Vision</h3>
            <p className="text-gray-600">
              To be recognized globally as a premier educational institution that nurtures creative thinkers,
              compassionate leaders, and responsible citizens who are equipped to address the challenges
              of an ever-changing world.
            </p>
          </div>
        </div>

        <div className="mt-16 flex flex-col md:flex-row items-center justify-between bg-blue-900 rounded-lg overflow-hidden">
          <div className="md:w-1/2 p-8 md:p-12">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Our Commitment to Excellence</h3>
            <p className="text-blue-100 mb-6">
              At Elite Academy, we are committed to maintaining the highest standards in education.
              Our experienced faculty, state-of-the-art facilities, and comprehensive curriculum
              ensure that every student receives an exceptional educational experience.
            </p>
            <button className="bg-gold-500 hover:bg-gold-600 text-white font-medium py-2 px-6 rounded-md transition duration-300">
              Learn More About Us
            </button>
          </div>
          <div className="md:w-1/2 h-64 md:h-auto">
            <img 
              src="https://images.pexels.com/photos/8844091/pexels-photo-8844091.jpeg" 
              alt="School building" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;