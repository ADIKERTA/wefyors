import React from 'react';
import { BookOpen, Compass, Award, Cpu, Palette, FlaskRound as Flask } from 'lucide-react';

const AcademicsSection: React.FC = () => {
  const programs = [
    {
      icon: <BookOpen className="text-blue-900" size={28} />,
      title: "Language & Literature",
      description: "Develop critical thinking and communication skills through intensive study of language, literature, and writing."
    },
    {
      icon: <Compass className="text-blue-900" size={28} />,
      title: "Social Sciences",
      description: "Explore human society, history, geography, economics and politics to understand our complex world."
    },
    {
      icon: <Award className="text-blue-900" size={28} />,
      title: "Mathematics",
      description: "Build analytical thinking through advanced mathematics curriculum from algebra to calculus."
    },
    {
      icon: <Flask className="text-blue-900" size={28} />,
      title: "Natural Sciences",
      description: "Discover the wonders of biology, chemistry, and physics through theory and hands-on laboratory work."
    },
    {
      icon: <Cpu className="text-blue-900" size={28} />,
      title: "Technology & Computing",
      description: "Develop essential digital skills from programming to digital media production and design."
    },
    {
      icon: <Palette className="text-blue-900" size={28} />,
      title: "Arts & Athletics",
      description: "Express creativity and build teamwork skills through comprehensive arts and sports programs."
    }
  ];

  return (
    <section id="academics" className="py-20 bg-blue-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Academic Excellence</h2>
          <div className="w-20 h-1 bg-gold-500 mx-auto"></div>
          <p className="text-gray-600 max-w-3xl mx-auto mt-6 text-lg">
            Our rigorous curriculum is designed to challenge students intellectually while fostering 
            creativity, critical thinking, and a love for learning.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {programs.map((program, index) => (
            <div 
              key={index} 
              className="bg-white p-8 rounded-lg shadow-sm transition-all duration-300 hover:shadow-md hover:-translate-y-1"
            >
              <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                {program.icon}
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-3">{program.title}</h3>
              <p className="text-gray-600">{program.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white rounded-lg overflow-hidden shadow-sm">
          <div className="grid md:grid-cols-2">
            <div className="p-8 md:p-12 flex flex-col justify-center">
              <h3 className="text-2xl md:text-3xl font-bold text-blue-900 mb-4">Curriculum Highlights</h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="bg-gold-100 rounded-full p-1 mr-3 mt-1">
                    <svg className="w-4 h-4 text-gold-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                    </svg>
                  </div>
                  <div>
                    <span className="font-medium text-blue-900">Interdisciplinary Approach</span>
                    <p className="text-gray-600 mt-1">Curriculum that connects subjects for deeper understanding</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="bg-gold-100 rounded-full p-1 mr-3 mt-1">
                    <svg className="w-4 h-4 text-gold-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                    </svg>
                  </div>
                  <div>
                    <span className="font-medium text-blue-900">Advanced Placement Options</span>
                    <p className="text-gray-600 mt-1">College-level courses for high-achieving students</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="bg-gold-100 rounded-full p-1 mr-3 mt-1">
                    <svg className="w-4 h-4 text-gold-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                    </svg>
                  </div>
                  <div>
                    <span className="font-medium text-blue-900">Project-Based Learning</span>
                    <p className="text-gray-600 mt-1">Real-world applications to solidify knowledge</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="bg-gold-100 rounded-full p-1 mr-3 mt-1">
                    <svg className="w-4 h-4 text-gold-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                    </svg>
                  </div>
                  <div>
                    <span className="font-medium text-blue-900">Small Class Sizes</span>
                    <p className="text-gray-600 mt-1">Personalized attention with 15:1 student-teacher ratio</p>
                  </div>
                </li>
              </ul>
              <button className="mt-8 bg-blue-900 hover:bg-blue-800 text-white font-medium py-2 px-6 rounded-md transition duration-300 self-start">
                View Full Curriculum
              </button>
            </div>
            <div className="relative h-64 md:h-auto">
              <img 
                src="https://images.pexels.com/photos/256541/pexels-photo-256541.jpeg" 
                alt="Students in classroom" 
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AcademicsSection;