import React from 'react';
import { GraduationCap } from 'lucide-react';

interface LogoProps {
  color: string;
}

export const Logo: React.FC<LogoProps> = ({ color }) => {
  return (
    <div className={`flex items-center ${color}`}>
      <GraduationCap className="mr-2" size={28} />
      <span className="font-bold text-xl">Elite Academy</span>
    </div>
  );
};