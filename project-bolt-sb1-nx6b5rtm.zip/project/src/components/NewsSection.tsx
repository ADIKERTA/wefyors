import React, { useState, useEffect, useRef } from 'react';
import { ArrowRight, Calendar } from 'lucide-react';

interface NewsItem {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  image: string;
  category: string;
}

const NewsSection: React.FC = () => {
  const newsItems: NewsItem[] = [
    {
      id: 1,
      title: "Students Win National Science Competition",
      excerpt: "Our science team secured first place at the National Science Olympiad with their innovative renewable energy project.",
      date: "May 15, 2025",
      image: "https://images.pexels.com/photos/8471826/pexels-photo-8471826.jpeg",
      category: "Achievement"
    },
    {
      id: 2,
      title: "New STEM Innovation Center Opening",
      excerpt: "We're excited to announce the opening of our state-of-the-art STEM Innovation Center, equipped with cutting-edge technology.",
      date: "April 28, 2025",
      image: "https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg",
      category: "Facilities"
    },
    {
      id: 3,
      title: "Annual Arts Festival Showcases Student Talent",
      excerpt: "This year's Arts Festival featured impressive performances and exhibitions from our talented students across all grades.",
      date: "March 12, 2025",
      image: "https://images.pexels.com/photos/4050288/pexels-photo-4050288.jpeg",
      category: "Events"
    },
    {
      id: 4,
      title: "Elite Academy Ranks Top 5 in National Rankings",
      excerpt: "We're proud to announce that Elite Academy has been ranked among the top 5 high schools in the country for academic excellence.",
      date: "February 20, 2025",
      image: "https://images.pexels.com/photos/5428833/pexels-photo-5428833.jpeg",
      category: "Recognition"
    }
  ];

  const [activeIndex, setActiveIndex] = useState(0);
  const timeoutRef = useRef<number | null>(null);
  const scrollDuration = 5000; // 5 seconds per slide

  const resetTimeout = () => {
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
    }
  };

  useEffect(() => {
    resetTimeout();
    timeoutRef.current = window.setTimeout(() => {
      setActiveIndex((prevIndex) => 
        prevIndex === newsItems.length - 1 ? 0 : prevIndex + 1
      );
    }, scrollDuration);

    return () => {
      resetTimeout();
    };
  }, [activeIndex, newsItems.length]);

  const goToSlide = (index: number) => {
    setActiveIndex(index);
  };

  return (
    <section id="news" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Latest News & Achievements</h2>
          <div className="w-20 h-1 bg-gold-500 mx-auto"></div>
          <p className="text-gray-600 max-w-3xl mx-auto mt-6 text-lg">
            Stay updated with the latest happenings, events, and achievements at Elite Academy.
          </p>
        </div>

        <div className="relative rounded-lg overflow-hidden shadow-lg mb-12">
          <div className="relative h-96 md:h-[32rem]">
            {newsItems.map((item, index) => (
              <div 
                key={item.id}
                className={`absolute inset-0 transition-opacity duration-1000 ${
                  index === activeIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'
                }`}
              >
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900 via-blue-900/60 to-transparent"></div>
                
                <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10 text-white">
                  <div className="inline-block px-3 py-1 bg-gold-500 text-white text-sm font-medium rounded-md mb-4">
                    {item.category}
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold mb-2">{item.title}</h3>
                  <p className="text-blue-100 mb-4 max-w-2xl">{item.excerpt}</p>
                  <div className="flex items-center text-blue-200 text-sm mb-6">
                    <Calendar size={16} className="mr-2" />
                    <span>{item.date}</span>
                  </div>
                  <button className="bg-white text-blue-900 hover:bg-gold-500 hover:text-white transition-colors duration-300 py-2 px-6 rounded-md font-medium inline-flex items-center">
                    <span>Read Full Story</span>
                    <ArrowRight size={16} className="ml-2" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-20 flex space-x-2">
            {newsItems.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                  index === activeIndex ? 'bg-gold-500' : 'bg-white/50'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              ></button>
            ))}
          </div>
        </div>

        <div className="flex justify-center">
          <button className="bg-blue-900 hover:bg-blue-800 text-white font-medium py-3 px-8 rounded-md transition duration-300 inline-flex items-center">
            <span>View All News & Events</span>
            <ArrowRight size={16} className="ml-2" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default NewsSection;