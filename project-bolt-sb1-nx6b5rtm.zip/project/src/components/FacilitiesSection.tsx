import React from 'react';
import { Library, FlaskRound as Flask, Laptop, BookOpen, Trophy, Music } from 'lucide-react';

const FacilitiesSection: React.FC = () => {
  const facilities = [
    {
      icon: <Library size={32} className="text-blue-900" />,
      title: "Modern Library",
      description: "A vast collection of books, digital resources, and quiet study spaces",
      image: "https://images.pexels.com/photos/1370296/pexels-photo-1370296.jpeg"
    },
    {
      icon: <Flask size={32} className="text-blue-900" />,
      title: "Science Labs",
      description: "Fully-equipped laboratories for biology, chemistry, and physics",
      image: "https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg"
    },
    {
      icon: <Laptop size={32} className="text-blue-900" />,
      title: "Computer Center",
      description: "State-of-the-art computer labs with the latest technology",
      image: "https://images.pexels.com/photos/1181243/pexels-photo-1181243.jpeg"
    },
    {
      icon: <BookOpen size={32} className="text-blue-900" />,
      title: "Auditorium",
      description: "Multi-purpose hall for assemblies, performances and events",
      image: "https://images.pexels.com/photos/159213/hall-congress-architecture-building-159213.jpeg"
    },
    {
      icon: <Trophy size={32} className="text-blue-900" />,
      title: "Sports Complex",
      description: "Indoor and outdoor facilities for various sports activities",
      image: "https://images.pexels.com/photos/1103829/pexels-photo-1103829.jpeg"
    },
    {
      icon: <Music size={32} className="text-blue-900" />,
      title: "Arts Center",
      description: "Dedicated spaces for music, visual arts, and performing arts",
      image: "https://images.pexels.com/photos/236705/pexels-photo-236705.jpeg"
    }
  ];

  return (
    <section id="facilities" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">World-Class Facilities</h2>
          <div className="w-20 h-1 bg-gold-500 mx-auto"></div>
          <p className="text-gray-600 max-w-3xl mx-auto mt-6 text-lg">
            Our campus is equipped with modern facilities that create an ideal environment for 
            learning, creativity, and personal growth.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {facilities.map((facility, index) => (
            <div 
              key={index}
              className="group rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={facility.image} 
                  alt={facility.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-blue-900 opacity-20 group-hover:opacity-40 transition-opacity duration-300"></div>
              </div>
              <div className="p-6 bg-white">
                <div className="flex items-center mb-4">
                  <div className="bg-blue-50 p-3 rounded-full mr-4">
                    {facility.icon}
                  </div>
                  <h3 className="text-xl font-bold text-blue-900">{facility.title}</h3>
                </div>
                <p className="text-gray-600">{facility.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="bg-blue-900 hover:bg-blue-800 text-white font-medium py-3 px-8 rounded-md transition duration-300 inline-flex items-center">
            <span>Schedule a Campus Tour</span>
            <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
            </svg>
          </button>
        </div>
      </div>
    </section>
  );
};

export default FacilitiesSection;