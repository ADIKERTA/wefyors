import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const TestimonialsSection: React.FC = () => {
  const testimonials = [
    {
      quote: "Elite Academy provided my daughter with an exceptional education that prepared her for university and beyond. The teachers' dedication and personalized approach made all the difference.",
      name: "Sarah Johnson",
      title: "Parent of Alumni",
      image: "https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg"
    },
    {
      quote: "As a former student, I can attest to the transformative education I received at Elite Academy. The rigorous academics and supportive environment helped me develop confidence and critical thinking skills.",
      name: "Michael Chen",
      title: "Alumni, Class of 2020",
      image: "https://images.pexels.com/photos/428364/pexels-photo-428364.jpeg"
    },
    {
      quote: "The holistic approach to education at Elite Academy helped my son discover his passion for science while also excelling in humanities. The school truly nurtures well-rounded individuals.",
      name: "Dr. Robert Williams",
      title: "Parent",
      image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg"
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <section className="py-20 bg-blue-900 text-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-64 h-64 rounded-full bg-blue-800 opacity-50 -translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full bg-blue-800 opacity-50 translate-x-1/3 translate-y-1/3"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Community Says</h2>
          <div className="w-20 h-1 bg-gold-500 mx-auto"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <div className="relative bg-blue-800 rounded-lg p-8 md:p-12 shadow-lg">
              <Quote className="absolute text-blue-700 opacity-20" size={80} />
              
              <div className="text-center">
                <p className="text-xl md:text-2xl italic mb-8 relative z-10">
                  "{testimonials[currentIndex].quote}"
                </p>
                
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 rounded-full overflow-hidden mb-4 border-2 border-gold-500">
                    <img 
                      src={testimonials[currentIndex].image} 
                      alt={testimonials[currentIndex].name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h4 className="text-xl font-bold">{testimonials[currentIndex].name}</h4>
                  <p className="text-blue-200">{testimonials[currentIndex].title}</p>
                </div>
              </div>
            </div>

            <div className="absolute top-1/2 -translate-y-1/2 -left-4 md:-left-8">
              <button 
                onClick={handlePrev}
                className="bg-white text-blue-900 rounded-full p-2 shadow-lg hover:bg-gold-500 hover:text-white transition-colors duration-300"
              >
                <ChevronLeft size={24} />
              </button>
            </div>
            <div className="absolute top-1/2 -translate-y-1/2 -right-4 md:-right-8">
              <button 
                onClick={handleNext}
                className="bg-white text-blue-900 rounded-full p-2 shadow-lg hover:bg-gold-500 hover:text-white transition-colors duration-300"
              >
                <ChevronRight size={24} />
              </button>
            </div>
          </div>

          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                  index === currentIndex ? 'bg-gold-500' : 'bg-blue-200'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;