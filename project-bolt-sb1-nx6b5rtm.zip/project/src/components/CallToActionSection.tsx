import React from 'react';
import { CalendarClock, FileText, Phone, Users } from 'lucide-react';

const CallToActionSection: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="bg-blue-900 rounded-2xl overflow-hidden shadow-xl">
          <div className="grid md:grid-cols-2">
            <div className="p-8 md:p-12 lg:p-16 flex flex-col justify-center">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Begin Your Journey at Elite Academy</h2>
              <p className="text-blue-100 mb-8 text-lg">
                Take the first step towards providing your child with an exceptional education that will prepare them for a successful future. Applications for the 2025-2026 academic year are now open.
              </p>
              <div className="space-y-4">
                <div className="flex items-center text-blue-100">
                  <div className="bg-blue-800 rounded-full p-2 mr-4">
                    <CalendarClock className="text-gold-500" size={20} />
                  </div>
                  <span>Applications close on July 31, 2025</span>
                </div>
                <div className="flex items-center text-blue-100">
                  <div className="bg-blue-800 rounded-full p-2 mr-4">
                    <FileText className="text-gold-500" size={20} />
                  </div>
                  <span>Limited seats available for each grade level</span>
                </div>
                <div className="flex items-center text-blue-100">
                  <div className="bg-blue-800 rounded-full p-2 mr-4">
                    <Users className="text-gold-500" size={20} />
                  </div>
                  <span>Schedule a campus tour to learn more</span>
                </div>
              </div>
              <div className="mt-10 flex flex-col sm:flex-row gap-4">
                <button className="bg-gold-500 hover:bg-gold-600 text-white font-medium py-3 px-6 rounded-md transition duration-300 text-base">
                  Apply Now
                </button>
                <button className="bg-transparent hover:bg-white/10 text-white border-2 border-white font-medium py-3 px-6 rounded-md transition duration-300 text-base inline-flex items-center justify-center">
                  <Phone size={18} className="mr-2" />
                  Schedule a Call
                </button>
              </div>
            </div>
            <div className="relative hidden md:block">
              <img 
                src="https://images.pexels.com/photos/764681/pexels-photo-764681.jpeg" 
                alt="Students walking on campus" 
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-blue-900 opacity-30"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToActionSection;