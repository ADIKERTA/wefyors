import React from 'react';
import { Logo } from './Logo';
import { MapPin, Phone, Mail, Clock, Facebook, Twitter, Instagram, Linkedin, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-blue-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div>
            <Logo color="text-white" />
            <p className="mt-4 text-blue-200">
              Elite Academy is committed to providing exceptional education that fosters academic excellence, 
              personal growth, and ethical leadership.
            </p>
            <div className="flex space-x-4 mt-6">
              <SocialIcon icon={<Facebook size={18} />} />
              <SocialIcon icon={<Twitter size={18} />} />
              <SocialIcon icon={<Instagram size={18} />} />
              <SocialIcon icon={<Linkedin size={18} />} />
              <SocialIcon icon={<Youtube size={18} />} />
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <FooterLink href="#" text="Home" />
              <FooterLink href="#about" text="About Us" />
              <FooterLink href="#academics" text="Academics" />
              <FooterLink href="#facilities" text="Facilities" />
              <FooterLink href="#news" text="News & Events" />
              <FooterLink href="#" text="Admissions" />
              <FooterLink href="#" text="Careers" />
              <FooterLink href="#contact" text="Contact Us" />
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Contact Information</h3>
            <ul className="space-y-4">
              <li className="flex">
                <MapPin className="text-gold-500 mr-3 shrink-0" size={20} />
                <span className="text-blue-200">123 Education Avenue, Knowledge City, State 12345</span>
              </li>
              <li className="flex">
                <Phone className="text-gold-500 mr-3 shrink-0" size={20} />
                <span className="text-blue-200">+1 (555) 123-4567</span>
              </li>
              <li className="flex">
                <Mail className="text-gold-500 mr-3 shrink-0" size={20} />
                <span className="text-blue-200">admissions@eliteacademy.edu</span>
              </li>
              <li className="flex">
                <Clock className="text-gold-500 mr-3 shrink-0" size={20} />
                <div className="text-blue-200">
                  <p>Monday - Friday: 8:00 AM - 4:00 PM</p>
                  <p>Saturday: 9:00 AM - 12:00 PM</p>
                </div>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Newsletter</h3>
            <p className="text-blue-200 mb-4">
              Subscribe to our newsletter to receive updates on school events, news, and important announcements.
            </p>
            <form className="space-y-3">
              <div>
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="w-full bg-blue-800 border border-blue-700 rounded-md py-2 px-4 text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-gold-500"
                />
              </div>
              <button className="bg-gold-500 hover:bg-gold-600 text-white font-medium py-2 px-4 rounded-md transition duration-300 w-full">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="border-t border-blue-800 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-blue-300 text-sm">
              &copy; {new Date().getFullYear()} Elite Academy. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-blue-300 hover:text-white text-sm">Privacy Policy</a>
              <a href="#" className="text-blue-300 hover:text-white text-sm">Terms of Service</a>
              <a href="#" className="text-blue-300 hover:text-white text-sm">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

interface FooterLinkProps {
  href: string;
  text: string;
}

const FooterLink: React.FC<FooterLinkProps> = ({ href, text }) => {
  return (
    <li>
      <a 
        href={href} 
        className="text-blue-200 hover:text-gold-500 transition-colors duration-300"
      >
        {text}
      </a>
    </li>
  );
};

interface SocialIconProps {
  icon: React.ReactNode;
}

const SocialIcon: React.FC<SocialIconProps> = ({ icon }) => {
  return (
    <a 
      href="#" 
      className="bg-blue-800 hover:bg-gold-500 h-8 w-8 rounded-full flex items-center justify-center transition-colors duration-300"
    >
      {icon}
    </a>
  );
};

export default Footer;