import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Logo } from './Logo';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
    }`}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <Logo color={isScrolled ? 'text-blue-900' : 'text-white'} />
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-8 items-center">
            <NavLinks textColor={isScrolled ? 'text-blue-900' : 'text-white'} />
            <button className="bg-gold-500 hover:bg-gold-600 text-white font-medium py-2 px-4 rounded-md transition duration-300">
              Apply Now
            </button>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={toggleMenu}
              className={`${isScrolled ? 'text-blue-900' : 'text-white'} focus:outline-none`}
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      <div className={`md:hidden ${isOpen ? 'block' : 'hidden'} bg-white shadow-lg absolute w-full`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col space-y-4">
            <NavLinks textColor="text-blue-900" mobile />
            <button className="bg-gold-500 hover:bg-gold-600 text-white font-medium py-2 px-4 rounded-md transition duration-300 w-full">
              Apply Now
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

interface NavLinksProps {
  textColor: string;
  mobile?: boolean;
}

const NavLinks: React.FC<NavLinksProps> = ({ textColor, mobile }) => {
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const links = [
    { name: 'Home', href: '#' },
    { 
      name: 'About', 
      href: '#about',
      dropdown: ['Our History', 'Mission & Vision', 'Leadership']
    },
    { 
      name: 'Academics', 
      href: '#academics',
      dropdown: ['Curriculum', 'Departments', 'Academic Calendar']
    },
    { name: 'Facilities', href: '#facilities' },
    { name: 'News', href: '#news' },
    { name: 'Contact', href: '#contact' },
  ];

  const toggleDropdown = (name: string) => {
    if (openDropdown === name) {
      setOpenDropdown(null);
    } else {
      setOpenDropdown(name);
    }
  };

  return (
    <>
      {links.map((link) => (
        <div key={link.name} className={`relative ${mobile ? 'w-full' : ''}`}>
          {link.dropdown ? (
            <div className={mobile ? 'w-full' : ''}>
              <button 
                onClick={() => toggleDropdown(link.name)}
                className={`${textColor} hover:text-gold-500 font-medium flex items-center justify-between ${mobile ? 'w-full' : ''}`}
              >
                {link.name}
                <ChevronDown size={16} className="ml-1" />
              </button>
              <div className={`${openDropdown === link.name ? 'block' : 'hidden'} ${
                mobile ? 'mt-2 bg-gray-50 rounded-md p-2' : 'absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg p-2'
              }`}>
                {link.dropdown.map((item) => (
                  <a 
                    key={item} 
                    href="#" 
                    className="block px-4 py-2 text-sm text-blue-900 hover:bg-blue-50 rounded-md"
                  >
                    {item}
                  </a>
                ))}
              </div>
            </div>
          ) : (
            <a 
              href={link.href} 
              className={`${textColor} hover:text-gold-500 font-medium ${mobile ? 'block w-full' : ''}`}
            >
              {link.name}
            </a>
          )}
        </div>
      ))}
    </>
  );
};

export default Navbar;