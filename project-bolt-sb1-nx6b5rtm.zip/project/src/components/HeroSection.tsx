import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.pexels.com/photos/207691/pexels-photo-207691.jpeg" 
          alt="Students in campus"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-blue-900 opacity-60"></div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 md:px-6 z-10">
        <div className="max-w-3xl text-white">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Nurturing Excellence, <br />Inspiring Futures
          </h1>
          <p className="text-lg md:text-xl mb-8 opacity-90">
            Elite Academy provides world-class education with a focus on academic excellence, 
            character development, and preparing students for global challenges.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-gold-500 hover:bg-gold-600 text-white font-medium py-3 px-6 rounded-md transition duration-300 text-base">
              Apply for Admission
            </button>
            <button className="bg-transparent hover:bg-white/10 text-white border-2 border-white font-medium py-3 px-6 rounded-md transition duration-300 text-base">
              Explore Programs
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center animate-bounce">
        <span className="text-white text-sm mb-2">Scroll Down</span>
        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
        </svg>
      </div>
    </section>
  );
};

export default HeroSection;